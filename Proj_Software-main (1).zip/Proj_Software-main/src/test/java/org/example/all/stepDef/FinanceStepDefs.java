package org.example.all.stepDef;

import io.cucumber.java.en.*;
import io.cucumber.datatable.DataTable;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class FinanceStepDefs {

    /* -------- نماذج مصغَّرة -------- */
    private record Order (String customer, String id, double amount) {}
    private record Invoice(String id, String orderId, double amount, LocalDate date) {}

    /* -------- الحالة -------- */
    private Map<String, Order>   orders;
    private Map<String, Invoice> invoicesByOrder;
    private List<Invoice>        invoices;
    private Map<String, Double>  expenses;

    private String        lastInvoiceError;
    private double        lastRevenue;
    private double        lastProfit;
    private List<String>  lastInvoiceIds;
    private String        lastReportMsg;

    /* -------- GIVEN -------- */

    @Given("the finance module is initialized")
    public void the_finance_module_is_initialized() {
        orders          = new HashMap<>();
        invoicesByOrder = new HashMap<>();
        invoices        = new ArrayList<>();
        expenses        = new HashMap<>();
        lastInvoiceError = null;
        lastReportMsg    = null;
        lastInvoiceIds   = new ArrayList<>();
    }

    @Given("customer {string} has completed order {string} worth {double}")
    public void customer_has_completed_order_worth(String customer, String orderId, Double amount) {
        orders.put(orderId, new Order(customer, orderId, amount));
    }

    @Given("invoice {string} already exists for order {string}")
    public void invoice_already_exists_for_order(String invoiceId, String orderId) {
        orders.putIfAbsent(orderId, new Order("Unknown", orderId, 0));
        Invoice inv = new Invoice(invoiceId, orderId, orders.get(orderId).amount, LocalDate.now());
        invoices.add(inv);
        invoicesByOrder.put(orderId, inv);
    }

    @Given("invoices exist:")
    public void invoices_exist(DataTable table) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        for (Map<String,String> row : table.asMaps()) {
            String id  = row.get("invoice");
            double amt = Double.parseDouble(row.get("amount"));
            LocalDate d= LocalDate.parse(row.get("date"), fmt);
            Invoice inv = new Invoice(id, "ORD-"+id, amt, d);
            invoices.add(inv);
            invoicesByOrder.put(inv.orderId(), inv);
        }
    }

    @Given("expenses for quarter {string} are {double}")
    public void expenses_for_quarter_are(String quarter, Double amount) {
        expenses.put(quarter, amount);
    }

    /* -------- WHEN -------- */

    @When("the system generates an invoice for order {string}")
    public void the_system_generates_an_invoice_for_order(String orderId) {
        if (!orders.containsKey(orderId)) { lastInvoiceError = "Order does not exist"; return; }
        if (invoicesByOrder.containsKey(orderId)) { lastInvoiceError = "Invoice already exists for order"; return; }

        Order o = orders.get(orderId);
        String invoiceId = "INV-" + orderId.split("-")[1];
        Invoice inv = new Invoice(invoiceId, orderId, o.amount(), LocalDate.now());
        invoices.add(inv);
        invoicesByOrder.put(orderId, inv);
    }

    @When("the administrator generates financial report for {string}")
    public void the_administrator_generates_financial_report_for(String period) {
        lastInvoiceIds.clear();
        lastRevenue = 0;
        lastReportMsg = null;

        if (period.matches("\\d{4}-\\d{2}")) {
            YearMonth ym = YearMonth.parse(period);
            lastRevenue = invoices.stream()
                    .filter(i -> YearMonth.from(i.date()).equals(ym))
                    .peek(i -> lastInvoiceIds.add(i.id()))
                    .mapToDouble(Invoice::amount)
                    .sum();
            if (lastRevenue == 0) lastReportMsg = "No invoices found for period";
        } else {
            lastReportMsg = "Unsupported period";
        }
    }

    @When("the administrator generates profit report for {string}")
    public void the_administrator_generates_profit_report_for(String qStr) {
        lastInvoiceIds.clear();
        QuarterRange q = QuarterRange.parse(qStr);
        lastRevenue = invoices.stream()
                .filter(i -> !i.date().isBefore(q.start) && !i.date().isAfter(q.end))
                .peek(i -> lastInvoiceIds.add(i.id()))
                .mapToDouble(Invoice::amount)
                .sum();
        lastProfit = lastRevenue - expenses.getOrDefault(qStr, 0.0);
    }

    /* -------- THEN -------- */

    @Then("the invoice {string} should be sent to customer {string}")
    public void the_invoice_should_be_sent_to_customer(String id, String customer) {
        Invoice inv = invoices.stream().filter(i -> i.id().equals(id)).findFirst().orElse(null);
        assertNotNull(inv, "Invoice not generated");
        assertEquals(customer, orders.get(inv.orderId()).customer());
    }

    @Then("the invoice amount should be {double}")
    public void the_invoice_amount_should_be(Double amt) {
        // compatible with Java ≤17
        Invoice latest = invoices.get(invoices.size() - 1);
        assertEquals(amt, latest.amount());
    }

    @Then("the system should show invoice error {string}")
    public void the_system_should_show_invoice_error(String msg) {
        assertEquals(msg, lastInvoiceError);
    }

    @Then("the report total revenue should be {double}")
    public void the_report_total_revenue_should_be(Double expected) {
        assertEquals(expected, lastRevenue);
    }

    @Then("the report should list invoices {string}")
    public void the_report_should_list_invoices(String csv) {
        List<String> exp = Arrays.asList(csv.replace(" ", "").split(","));
        assertEquals(new HashSet<>(exp), new HashSet<>(lastInvoiceIds));
    }

    @Then("the report total profit should be {double}")
    public void the_report_total_profit_should_be(Double expected) {
        assertEquals(expected, lastProfit);
    }

    @Then("the system should show report message {string}")
    public void the_system_should_show_report_message(String msg) {
        assertEquals(msg, lastReportMsg);
    }

    /* -------- أداة مساعدة -------- */

    private record QuarterRange(LocalDate start, LocalDate end) {
        static QuarterRange parse(String qStr){
            String[] p = qStr.split("-Q");
            int y = Integer.parseInt(p[0]);
            int q = Integer.parseInt(p[1]);
            Month start;
            switch (q){
                case 1 -> start = Month.FEBRUARY;   // Feb-Apr
                case 2 -> start = Month.MAY;        // May-Jul
                case 3 -> start = Month.AUGUST;     // Aug-Oct
                case 4 -> start = Month.NOVEMBER;   // Nov-Jan
                default -> throw new IllegalArgumentException("Bad quarter "+qStr);
            }
            LocalDate s = LocalDate.of(y, start, 1);
            LocalDate e = s.plusMonths(2).withDayOfMonth(s.plusMonths(2).lengthOfMonth());
            return new QuarterRange(s, e);
        }
    }
}
