// feature 4.2  –  Supplier Price Integration & PO handling
package org.example.all.stepDef;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

/**
 *  كيانات بسيطة لحفظ الحالة أثناء السيناريوهات
 */
public class SupplierPriceIntegrationStepDefs {

    /* ---------- كيانات ---------- */

    /** عرض سعر واحد من مورّد */
    static class Offer {
        String supplier;
        double price;
        Offer(String s, double p) { supplier = s; price = p; }
    }

    /** أمر شراء */
    static class PO {
        String item;
        int qty;
        String supplier;
        String status = "Pending";
        PO(String i, int q, String s) { item = i; qty = q; supplier = s; }
        String label() { return item + " x" + qty; }
    }

    /** صندوق رسائل عام (لأي جهة) */
    static class Inbox {
        List<String> messages = new ArrayList<>();
        void notify(String msg) { messages.add(msg); }
        boolean contains(String msg) { return messages.contains(msg); }
    }

    /* ---------- حالة الاختبار ---------- */

    private final Map<String, List<Offer>> catalog   = new HashMap<>();   // item → عروض
    private final Map<String, PO>          poStore   = new HashMap<>();   // "Tomatoes x50" → PO
    private final Map<String, Inbox>       supplierInboxes = new HashMap<>();
    private final Inbox                    managerInbox    = new Inbox();

    private Offer  chosenOffer  = null;  // نتيجة مقارنة الأسعار
    private String lastErrorMsg = null;  // لخطوة الخطأ

    /* ---------- إعادة الضبط لكل سيناريو ---------- */
    @Before
    public void reset() {
        catalog.clear();
        poStore.clear();
        supplierInboxes.clear();
        managerInbox.messages.clear();
        chosenOffer  = null;
        lastErrorMsg = null;
    }

    /* ---------- Background ---------- */
    @Given("the supplier system is initialized")
    public void supplier_system_initialized() {
        // لا حاجة لمنطق إضافي؛ تمّ الضبط في ‎@Before
    }

    /* ---------- تسجيل عروض الأسعار ---------- */
    @Given("supplier {string} offers {string} at price {double}")
    public void supplier_offers_item_at_price(String sup, String item, Double price) {
        catalog.computeIfAbsent(item, k -> new ArrayList<>()).add(new Offer(sup, price));
        supplierInboxes.putIfAbsent(sup, new Inbox());
    }

    /* ---------- مقارنة الأسعار ---------- */
    @When("the manager compares suppliers for {string}")
    public void manager_compares_suppliers_for(String item) {
        var offers = catalog.getOrDefault(item, List.of());
        if (offers.isEmpty()) {
            lastErrorMsg = "No supplier found for item";
            return;
        }
        chosenOffer = offers.stream().min(Comparator.comparingDouble(o -> o.price)).orElse(null);
    }

    @Then("the system should select supplier {string} with price {double}")
    public void system_selects_supplier_with_price(String sup, Double price) {
        assertNotNull(chosenOffer, "No supplier was selected");
        assertEquals(sup,   chosenOffer.supplier);
        assertEquals(price, chosenOffer.price);
    }

    /* ---------- إنشاء أمر شراء ---------- */
    @When("the manager places a purchase order for {string} quantity {int}")
    public void manager_places_purchase_order(String item, Integer qty) {
        var offers = catalog.get(item);
        if (offers == null || offers.isEmpty()) {
            lastErrorMsg = "No supplier found for item";
            return;
        }
        Offer best = offers.stream().min(Comparator.comparingDouble(o -> o.price)).get();
        PO po = new PO(item, qty, best.supplier);
        poStore.put(po.label(), po);
        supplierInboxes.get(best.supplier).notify("PO " + po.label());
    }

    @Then("supplier {string} should receive PO {string}")
    public void supplier_should_receive_po(String sup, String label) {
        Inbox box = supplierInboxes.get(sup);
        assertNotNull(box, "Supplier not registered");
        assertTrue(box.contains("PO " + label));
    }

    /* ---------- خطوة الخطأ العامة ---------- */
    @Then("the system should show error {string}")
    public void the_system_should_show_error(String expected) {
        assertEquals(expected, lastErrorMsg);
    }

    /* ---------- إعداد PO مُسبق (للتأكيد/الرفض/التقرير) ---------- */
    @Given("supplier {string} is selected for {string} quantity {int}")
    public void supplier_selected_for_item(String sup, String item, Integer qty) {
        supplierInboxes.putIfAbsent(sup, new Inbox());
        PO po = new PO(item, qty, sup);
        poStore.put(po.label(), po);
        supplierInboxes.get(sup).notify("PO " + po.label());
    }

    /* ---------- تأكيد المورّد ---------- */
    @When("supplier {string} confirms PO {string}")
    public void supplier_confirms_po(String sup, String label) {
        PO po = poStore.get(label);
        assertNotNull(po);
        assertEquals(sup, po.supplier);
        po.status = "Confirmed";
    }

    @Then("the system should mark PO {string} as {string}")
    public void system_marks_po_as(String label, String status) {
        PO po = poStore.get(label);
        assertNotNull(po);
        assertEquals(status, po.status);
    }

    /* ---------- رفض المورّد ---------- */
    @When("supplier {string} declines PO {string}")
    public void supplier_declines_po(String sup, String label) {
        PO po = poStore.get(label);
        assertNotNull(po);
        assertEquals(sup, po.supplier);
        po.status = "Declined";
        managerInbox.notify("PO " + label + " was declined");
    }

    @Then("the manager should receive notification {string}")
    public void the_manager_should_receive_notification(String msg) {
        assertTrue(managerInbox.contains(msg));
    }

    /* ---------- تقرير الطلبات المعلّقة ---------- */
    @When("the manager requests pending POs report")
    public void manager_requests_pending_report() {
        // لا حاجة لحساب فوري؛ سنتحقق مباشرة لاحقًا
    }

    @Then("the system should display report lines:")
    public void system_displays_report_lines(DataTable expected) {
        List<String> expectedLines = expected.asList();
        List<String> pending = poStore.values().stream()
                .filter(po -> "Pending".equals(po.status))
                .map(po -> po.label() + " (Pending)")
                .toList();
        assertEquals(expectedLines.size(), pending.size());
        assertTrue(pending.containsAll(expectedLines));
    }
}
