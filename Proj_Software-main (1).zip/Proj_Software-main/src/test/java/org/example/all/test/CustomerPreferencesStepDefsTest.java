//feature 1.1
package org.example.all.stepDef;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CustomerPreferencesStepDefsTest {

    private CustomerPreferencesStepDefs stepDefs;

    @BeforeEach
    void setup() {
        stepDefs = new CustomerPreferencesStepDefs();
        stepDefs.seedCustomers();
    }

    @Test
    void testValidInput() {
        assertTrue(invokeIsValid("Vegetarian"));
        assertTrue(invokeIsValid("Gluten-Free"));
        assertTrue(invokeIsValid("Low Carb"));
    }

    @Test
    void testInvalidInput_withNumbers() {
        assertFalse(invokeIsValid("1234"));
        assertFalse(invokeIsValid("Milk99"));
    }

    @Test
    void testInvalidInput_withSpecialChars() {
        assertFalse(invokeIsValid("@@@"));
        assertFalse(invokeIsValid("Vegan@"));
        assertFalse(invokeIsValid("Peanut#"));
    }

    @Test
    void testAddNewCustomerAndSavePreferenceAllergy() {
        String email = "testuser@test.com";
        String pref = "Keto";
        String allergy = "Soy";

        stepDefs.enter_preference_and_allergy(email, pref, allergy);
        stepDefs.submits_information();

        stepDefs.saved_preference_allergy(email);
    }

    @Test
    void testUpdateExistingPreference() {
        String email = "ali@test.com";
        stepDefs.customer_has_preferences(email);
        stepDefs.update_preference("Carnivore");

        stepDefs.assert_updated_preference(email);
    }

    @Test
    void testChefViewNoDataCustomer() {
        String email = "newuser@test.com";
        stepDefs.chef_opens_profile(email);
        stepDefs.system_displays_message("No preferences found for this customer");
    }

    private boolean invokeIsValid(String value) {
        try {
            var method = CustomerPreferencesStepDefs.class.getDeclaredMethod("isValid", String.class);
            method.setAccessible(true);
            return (boolean) method.invoke(stepDefs, value);
        } catch (Exception e) {
            fail("Failed to invoke isValid method: " + e.getMessage());
            return false;
        }
    }
}
