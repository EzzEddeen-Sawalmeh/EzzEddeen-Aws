// feature 3.1
package org.example.all.test;

import org.example.all.stepDef.TaskAssignmentStepDefs;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskAssignmentStepDefsTest {

    private TaskAssignmentStepDefs stepDefs;

    @BeforeEach
    void setUp() {
        stepDefs = new TaskAssignmentStepDefs();
        stepDefs.system_initialized();
    }


    @Test
    void testAssignTaskWithMatchingExpertise() {
        stepDefs.chef_has_expertise("Ali", "Grilling", 2);
        stepDefs.task_requires_expertise("Grill Chicken", "Grilling");
        stepDefs.assign_task("Grill Chicken");
        stepDefs.task_should_be_assigned("Ali");
    }

    @Test
    void testPreferChefWithLessWorkload() {
        stepDefs.chef_has_expertise("Layla", "Grilling", 1);
        stepDefs.chef_has_expertise("Ali", "Grilling", 3);
        stepDefs.task_requires_expertise("Grill Vegetables", "Grilling");
        stepDefs.assign_task("Grill Vegetables");
        stepDefs.task_should_be_assigned("Layla");
    }

    @Test
    void testErrorIfNoChefWithRequiredExpertise() {
        stepDefs.chef_has_expertise("Sara", "Baking", 2);
        stepDefs.task_requires_expertise("Fry Fish", "Frying");
        stepDefs.assign_task("Fry Fish");
        stepDefs.show_error_message("No available chef with required expertise");
    }


    @Test
    void testChefReceivesSingleNotification() {
        stepDefs.chef_is_available("Ali");
        stepDefs.assign_task_to("Grill Steak", "Ali");
        stepDefs.chef_should_receive_notification("Ali", "You have been assigned: Grill Steak");
    }

    @Test
    void testChefReceivesMultipleTasksNotification() {
        stepDefs.chef_is_available("Layla");
        stepDefs.assign_task_to("Bake Pie", "Layla");
        stepDefs.assign_task_to("Bake Cake", "Layla");
        stepDefs.chef_should_receive_notification("Layla", "You have been assigned: Bake Pie, Bake Cake");
    }

    @Test
    void testReassignTaskNotification() {
        stepDefs.chef_is_available("Sara");
        stepDefs.chef_is_available("Karim");
        stepDefs.chef_was_assigned_to("Sara", "Chop Vegetables");
        stepDefs.reassign_task("Chop Vegetables", "Karim");

        stepDefs.chef_should_receive_notification("Sara", "Task 'Chop Vegetables' has been reassigned");
        stepDefs.chef_should_receive_notification("Karim", "You have been assigned: Chop Vegetables");
    }
}
