//feature 2.2

package org.example.all.test;

import org.example.all.stepDef.IngredientSubstitutionSteps;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IngredientSubstitutionStepsTest {

    private IngredientSubstitutionSteps steps;

    @BeforeEach
    void setUp() {
        steps = new IngredientSubstitutionSteps();
        steps.the_customer_is_logged_in_and_customizing_a_meal();
    }

    @Test
    void testUnavailableIngredientSubstitution() {
        steps.the_customer_selects_ingredients("Caviar, Rice");
        steps.the_system_suggests_alternatives_for_unavailable_ingredients();
        steps.the_suggested_substitutions_include("Mushrooms");
    }

    @Test
    void testSingleDietaryRestrictionSubstitution() {
        steps.the_customer_selects_ingredients("Milk, Oats");
        steps.the_dietary_restriction_is("No Dairy");
        steps.the_system_suggests_alternatives_for_restricted_ingredients();
        steps.the_suggested_substitutions_include("Almond Milk");
    }

    @Test
    void testMultipleDietaryRestrictions() {
        steps.the_customer_selects_ingredients("Beef, Cheese, Bread");
        steps.the_dietary_restriction_is("No Red Meat, No Dairy");
        steps.the_system_suggests_alternatives_for_restricted_ingredients();
        steps.the_suggested_substitutions_include("Chicken, Vegan Cheese");
    }

    @Test
    void testChefReceivesNotification() {
        steps.a_substitution_was_made_for_a_custom_meal();
        steps.the_chef_is_notified_with_the_substituted_ingredients();
    }

    @Test
    void testChefViewsSubstitutionList() {
        steps.a_substitution_was_made_for_a_custom_meal();
        steps.the_chef_opens_the_meal_request();
        steps.the_system_shows_the_list_of_substituted_ingredients();
    }

    @Test
    void testChefEditsSubstitution() {
        steps.a_substitution_was_made_for_a_custom_meal();
        steps.the_chef_edits_the_substituted_ingredients();
        steps.the_updated_substitutions_are_saved();
    }
}
