//feature 3.1
package org.example.all.stepDef;


import io.cucumber.java.en.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class TaskAssignmentStepDefs {

    private final Map<String, String> requiredExpertise = new HashMap<>();
    private final Map<String, String> assignedChef      = new HashMap<>();
    private final Map<String, List<String>> chefTasks   = new HashMap<>();
    private final Map<String, List<String>> chefNotes   = new HashMap<>();

    /* -------- GIVEN -------- */

    @Given("the kitchen system is initialized")
    public void system_initialized() {
        requiredExpertise.clear();
        assignedChef.clear();
        chefTasks.clear();
        chefNotes.clear();
    }

    @Given("chef {string} has expertise {string} and {int} tasks")
    public void chef_has_expertise(String chef, String exp, int tasks) {
        chefTasks.put(chef, new ArrayList<>());
        // تسجيل عدد المهام لاعتبار الحمل (work-load)
        for (int i = 0; i < tasks; i++) chefTasks.get(chef).add("T" + i);
        requiredExpertise.put(chef, exp);
        chefNotes.put(chef, new ArrayList<>());
    }

    @Given("task {string} requires expertise {string}")
    public void task_requires_expertise(String task, String exp) {
        // نخزّن المتطلّب حتى نستخدمه في التعيين
        requiredExpertise.put(task, exp);
    }

    @Given("chef {string} is available")
    public void chef_is_available(String chef) {
        chefTasks.putIfAbsent(chef, new ArrayList<>());
        chefNotes.putIfAbsent(chef, new ArrayList<>());
    }

    @Given("chef {string} was assigned to {string}")
    public void chef_was_assigned_to(String chef, String task) {
        assignInternally(chef, task);
    }

    /* -------- WHEN -------- */

    @When("the manager assigns task {string}")
    public void assign_task(String task) {
        String exp = requiredExpertise.get(task);
        // اختر الشيف الأقل حملاً مع نفس الخبرة
        Optional<String> chefOpt = chefTasks.entrySet().stream()
                .filter(e -> exp.equals(requiredExpertise.get(e.getKey())))
                .min(Comparator.comparingInt(e -> e.getValue().size()))
                .map(Map.Entry::getKey);

        if (chefOpt.isEmpty()) {
            chefNotes.computeIfAbsent("SYSTEM", k -> new ArrayList<>())
                    .add("No available chef with required expertise");
            return;
        }
        assignInternally(chefOpt.get(), task);
    }

    @When("task {string} is assigned to {string}")
    public void assign_task_to(String task, String chef) {
        assignInternally(chef, task);
    }

    @When("the manager reassigns task {string} to {string}")
    public void reassign_task(String task, String newChef) {
        String oldChef = assignedChef.get(task);
        if (oldChef != null) {
            chefNotes.get(oldChef)
                    .add("Task '" + task + "' has been reassigned");
            chefTasks.get(oldChef).remove(task);
        }
        assignInternally(newChef, task);
    }

    /* -------- THEN -------- */

    @Then("the task should be assigned to {string}")
    public void task_should_be_assigned(String chef) {
        assertTrue(assignedChef.containsValue(chef));
    }

    @Then("the kitchen system should show error {string}")
    public void show_error_message(String msg) {
        List<String> errs = chefNotes.getOrDefault("SYSTEM", List.of());
        assertTrue(errs.contains(msg), "Expected error not found. All errors: " + errs);
    }

    @Then("chef {string} should receive notification {string}")
    public void chef_should_receive_notification(String chef, String expected) {

        List<String> notes = chefNotes.getOrDefault(chef, List.of());

        // إذا لم نجد الرسالة المجمَّعة، فلنركّبها من الرسائل الفرديّة
        if (!notes.contains(expected) &&
                expected.startsWith("You have been assigned:")) {

            String prefix = "You have been assigned: ";
            List<String> tasks = new ArrayList<>();
            notes.stream()
                    .filter(n -> n.startsWith(prefix))
                    .forEach(n -> tasks.addAll(Arrays.asList(
                            n.substring(prefix.length()).split(",\\s*"))));

            String combined = prefix + String.join(", ", tasks);
            assertEquals(expected, combined,
                    "المهام موجودة لكن لم تُدمَج كما هو متوقَّع");
        } else {
            assertTrue(notes.contains(expected),
                    "Expected notification not found.\nAll notifications: " + notes);
        }
    }

    /* -------- أدوات داخلية -------- */

    private void assignInternally(String chef, String task) {
        chefTasks.computeIfAbsent(chef, k -> new ArrayList<>()).add(task);
        assignedChef.put(task, chef);

        // أنشئ إشعارًا بدمج جميع المهام الحالية لهذا الشيف
        List<String> tasks = chefTasks.get(chef);
        String note = "You have been assigned: " + String.join(", ", tasks);
        chefNotes.computeIfAbsent(chef, k -> new ArrayList<>());

        // أزل أي إشعارات قديمة تبدأ بالجملة نفسها
        chefNotes.get(chef).removeIf(n -> n.startsWith("You have been assigned:"));
        chefNotes.get(chef).add(note);
    }
}
