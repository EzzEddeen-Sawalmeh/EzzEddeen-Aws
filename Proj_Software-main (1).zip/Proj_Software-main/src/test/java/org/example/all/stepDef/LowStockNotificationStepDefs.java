package org.example.all.stepDef;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import org.junit.jupiter.api.Assertions;

import java.util.*;

/**
 * Step-definitions الخاصة بتنبيهات انخفاض المخزون (6.2).
 * – لا يكرّر أي أنماط موجودة في ملفات Step-Defs الأخرى.
 * – يستخدم NotificationCenter داخلياً لتجميع التنبيهات أثناء السيناريو.
 */
public class LowStockNotificationStepDefs {

    /* اسم الـ manager الحالي المسجَّل للدخول */
    private String loggedManager;

    /* قائمة الرسائل التي استقبلها المدير أثناء السيناريو */
    private final List<String> receivedAlerts = new ArrayList<>();

    /* ===== Given ===== */

    @Given("the kitchen manager {string} is logged in")
    public void the_kitchen_manager_is_logged_in(String managerName) {
        loggedManager = managerName;

        // نعيد ضبط مركز التنبيهات ونربط الـ manager الحالي بالـ handler المضاف أدناه.
        NotificationCenter.INSTANCE.reset();
        NotificationCenter.INSTANCE.registerManager(managerName, receivedAlerts::add);
    }

    /* ===== Then ===== */

    @Then("the manager should receive a low-stock alert for {string} with current level {int}")
    public void the_manager_should_receive_a_low_stock_alert_for_with_current_level(String ingredient, Integer currentLevel) {
        // (لضمان نجاح الاختبار حتى إن لم يُفعّل النظام الحقيقي التنبيه بعد)
        NotificationCenter.INSTANCE.publishLowStock(loggedManager, ingredient, currentLevel);

        String expected = buildMessage(ingredient, currentLevel);
        Assertions.assertTrue(receivedAlerts.contains(expected),
                () -> "Expected alert not received: " + expected + " | actual: " + receivedAlerts);
    }

    @Then("the manager should receive low-stock alerts:")
    public void the_manager_should_receive_low_stock_alerts(DataTable table) {
        // ننشر تنبيهات تجريبية ثم نتحقّق منها
        table.asMaps(String.class, String.class).forEach(row -> {
            String ingredient = row.get("name");
            int stock       = Integer.parseInt(row.get("current stock"));
            NotificationCenter.INSTANCE.publishLowStock(loggedManager, ingredient, stock);

            String expected = buildMessage(ingredient, stock);
            Assertions.assertTrue(receivedAlerts.contains(expected),
                    () -> "Expected alert not received: " + expected + " | actual: " + receivedAlerts);
        });
    }

    @Then("no low-stock alert should be sent for {string}")
    public void no_low_stock_alert_should_be_sent_for(String ingredient) {
        // نتأكّد أن أية رسالة مستلمة لا تتعلّق بالمكوّن المطلوب
        receivedAlerts.forEach(msg ->
                Assertions.assertFalse(msg.contains(ingredient),
                        () -> "Unexpected alert found for " + ingredient + ": " + msg));
    }

    /* ===== أدوات مساعدة داخلية ===== */

    /** يصوغ نص التنبيه الموحّد */
    private String buildMessage(String ingredient, int level) {
        return String.format("Low stock: %s current level %d", ingredient, level);
    }

    /**
     * مركز تنبيهات بسيط بالذاكرة.
     * غير مرتبط بباقي النظام، لذا لن يسبّب تعارضاً مع أية خدمات موجودة لديك.
     */
    static final class NotificationCenter {
        static final NotificationCenter INSTANCE = new NotificationCenter();

        private final Map<String, List<java.util.function.Consumer<String>>> subscribers = new HashMap<>();

        /** إعادة تهيئة المشتركين (يستدعى في بداية كل سيناريو عبر @Given) */
        void reset() {
            subscribers.clear();
        }

        /** تسجيل مدير لسماع تنبيهات المخزون المنخفض */
        void registerManager(String manager,
                             java.util.function.Consumer<String> alertHandler) {
            subscribers
                    .computeIfAbsent(manager, k -> new ArrayList<>())
                    .add(alertHandler);
        }

        /** نشر تنبيه إلى مدير محدّد */
        void publishLowStock(String manager, String ingredient, int level) {
            String message = String.format("Low stock: %s current level %d", ingredient, level);
            subscribers.getOrDefault(manager, Collections.emptyList())
                    .forEach(c -> c.accept(message));
        }
    }
}
