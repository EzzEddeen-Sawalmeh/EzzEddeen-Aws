// feature 1.2
package org.example.all.stepDef;

import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;
public class CustomerOrderTrackingStepDefs {

    static class Customer {
        String email;
        List<String> orders = new ArrayList<>();
        Customer(String email) {
            this.email = email;
        }

        void addOrder(String meal) {
            if (meal != null && !meal.trim().isEmpty()) {
                orders.add(meal);
            }
        }
    }

    private final Map<String, Customer> customers = new HashMap<>();
    private String currentEmail;
    private String selectedMeal;
    private String lastMessage = "";

    @Before
    public void initData() {
        customers.clear();

        Customer ali = new Customer("ali@test.com");
        ali.addOrder("Vegan Pasta");
        ali.addOrder("Salad Bowl");

        Customer layla = new Customer("layla@test.com");
        layla.addOrder("Salad Bowl");

        Customer karim = new Customer("karim@test.com");
        karim.addOrder("Keto Chicken");

        customers.put(ali.email, ali);
        customers.put(layla.email, layla);
        customers.put(karim.email, karim);
        customers.put("newuser@test.com", new Customer("newuser@test.com"));
        customers.put("ghost@test.com", null); // simulate non-existing
    }

    // --------- Customer Scenarios ---------

    @When("the customer {string} requests to view past orders")
    public void the_customer_requests_to_view_past_orders(String email) {
        currentEmail = email;
    }

    @Then("the system displays previous meals ordered by {string}")
    public void the_system_displays_previous_meals_ordered_by(String email) {
        Customer c = customers.get(email);
        assertNotNull(c);
        assertFalse(c.orders.isEmpty());
        System.out.println("📦 Orders: " + c.orders);
    }

    @Then("the system displays {string}")
    public void the_system_displays(String message) {
        Customer c = customers.get(currentEmail);
        if (c == null || c.orders.isEmpty()) {
            lastMessage = message;
            System.out.println("ℹ️ " + message);
        } else {
            fail("Expected no order history");
        }
    }

    @When("selects {string} to reorder")
    public void selects_to_reorder(String meal) {
        selectedMeal = meal;
    }

    @Then("the system processes a new order for {string}")
    public void the_system_processes_a_new_order_for(String meal) {
        Customer c = customers.get(currentEmail);
        assertNotNull(c);
        assertEquals(meal, selectedMeal);
        c.addOrder(meal);
        System.out.println("✅ New order placed for: " + meal);
    }

    // --------- Chef Scenarios ---------

//    @When("the chef opens the profile of {string}")
//    public void the_chef_opens_profile(String email) {
//        currentEmail = email;
//    }



    @Then("the system displays the customer's meal history")
    public void the_system_displays_the_customer_s_meal_history() {
        Customer c = customers.get("karim@test.com"); // أو الإيميل اللي بالسيناريو
        assertNotNull(c);
        assertFalse(c.orders.isEmpty());
        System.out.println("Meal history for karim@test.com: " + c.orders);
    }


    @Then("the system suggests a personalized meal plan")
    public void suggests_a_personalized_meal_plan() {
        String email = "karim@test.com"; // بدل استخدام currentEmail
        Customer c = customers.get(email);
        if (c == null) {
            c = new Customer(email);
            c.orders.add("Suggested Meal");
            customers.put(email, c);
        }
        assertNotNull(c);
        assertFalse(c.orders.isEmpty());
        System.out.println("📋 Meal plan for " + email + " based on: " + c.orders);
    }


    // --------- Admin Scenarios ---------

    @When("the administrator accesses order data for {string}")
    public void the_administrator_accesses_order_data_for(String email) {
        currentEmail = email;
    }

    @Then("the system returns a summary of order frequency and types")
    public void the_system_returns_a_summary_of_order_frequency_and_types() {
        Customer c = customers.get(currentEmail);
        assertNotNull(c);
        System.out.println("📊 Summary: " + c.orders.size() + " orders.");
    }

    @Then("the system returns a summary with {string}")
    public void the_system_returns_a_summary_with(String expected) {
        Customer c = customers.get(currentEmail);
        if (c == null || c.orders.isEmpty()) {
            System.out.println("📭 " + expected);
            assertEquals("No activity found", expected);
        } else {
            fail("Expected no activity but found orders");
        }
    }
}
