package org.example.all.stepDef;

import io.cucumber.java.en.*;
import io.cucumber.datatable.DataTable;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

/**
 * Step-definitions الخاصة بميزة إدارة المخزون وإعادة الطلب.
 */
public class InventoryManagementStepDefs {

    /**  هيكل بسيط لتخزين مستوى المخزون والحدّ الأدنى  */
    private static class IngredientInfo {
        int stock;
        int threshold;
        IngredientInfo(int stock, int threshold) {
            this.stock = stock;
            this.threshold = threshold;
        }
    }

    private Map<String, IngredientInfo> inventory;   // <اسم المكوّن, بياناته>
    private List<String> restockSuggestions;         // المكوّنات المقترح إعادة طلبها
    private String lastMessage;                      // آخر رسالة معروضة للمستخدم

    /* -------------------------------------------------------------------------------- */

    /* ============ GIVEN ============ */

    @Given("the inventory system is initialized")
    public void the_inventory_system_is_initialized() {
        inventory = new HashMap<>();
        restockSuggestions = new ArrayList<>();
        lastMessage = null;
    }

    @Given("the ingredient {string} has a stock level of {int}")
    public void the_ingredient_has_a_stock_level_of(String name, Integer stock) {
        inventory.put(name, new IngredientInfo(stock, 5));   // حدّ افتراضي = 5
    }

    @Given("the ingredient {string} has a stock level of {int} and restock threshold is {int}")
    public void the_ingredient_has_a_stock_level_of_and_restock_threshold_is(
            String name, Integer stock, Integer threshold) {
        inventory.put(name, new IngredientInfo(stock, threshold));
    }

    @Given("the following ingredients and stock levels:")
    public void the_following_ingredients_and_stock_levels(DataTable table) {
        for (Map<String, String> row : table.asMaps()) {
            String name = row.get("name");
            int stock = Integer.parseInt(row.get("stock"));
            int threshold = Integer.parseInt(row.get("threshold"));
            inventory.put(name, new IngredientInfo(stock, threshold));
        }
    }

    /* ============ WHEN ============ */

    @When("the kitchen manager checks stock for {string}")
    public void the_kitchen_manager_checks_stock_for(String name) {
        IngredientInfo info = inventory.get(name);
        if (info == null || info.stock == 0) {
            lastMessage = name + " is out of stock";
        } else if (info.stock < info.threshold) {
            lastMessage = "Stock for " + name + " is low: " + info.stock + " units";
        } else {
            lastMessage = "Stock for " + name + " is sufficient: " + info.stock + " units";
        }
    }

    @When("the system checks ingredient levels")
    public void the_system_checks_ingredient_levels() {
        restockSuggestions.clear();
        for (Map.Entry<String, IngredientInfo> entry : inventory.entrySet()) {
            if (entry.getValue().stock < entry.getValue().threshold) {
                restockSuggestions.add(entry.getKey());
            }
        }
    }

    @When("the system checks all ingredient levels")
    public void the_system_checks_all_ingredient_levels() {
        the_system_checks_ingredient_levels();   // نفس المنطق
    }

    /* ============ THEN ============ */

    @Then("the system should display {string}")
    public void the_system_should_display(String expected) {
        assertEquals(expected, lastMessage);
    }

    @Then("it should suggest restocking {string}")
    public void it_should_suggest_restocking(String name) {
        assertTrue(restockSuggestions.contains(name),
                "Expected " + name + " in restock list " + restockSuggestions);
    }

    @Then("it should not suggest restocking {string}")
    public void it_should_not_suggest_restocking(String name) {
        assertFalse(restockSuggestions.contains(name),
                "Did not expect " + name + " in " + restockSuggestions);
    }

    @Then("it should suggest restocking for:")
    public void it_should_suggest_restocking_for(DataTable expectedTable) {
        // نحصل على الأسماء من الجدول (نتجاهل صف العنوان بطريقة asMaps)
        List<String> expectedNames = new ArrayList<>();
        for (Map<String, String> row : expectedTable.asMaps()) {
            expectedNames.add(row.get("name"));
        }

        assertEquals(expectedNames.size(), restockSuggestions.size(),
                "Mismatch in number of suggestions");
        assertTrue(restockSuggestions.containsAll(expectedNames),
                "Expected " + expectedNames + " but got " + restockSuggestions);
    }
}
