package org.example.all.stepDef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Step-definitions for reminders.feature
 */
public class ReminderStepDefs {

    // ـــــــــــــــــــــــ🔧  دعم داخلي بسيط  🔧ـــــــــــــــــــــــ

    private static final class ReminderService {
        private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        private final Map<String, LocalDateTime> orders = new HashMap<>();         // email → delivery time
        private final Map<String, LocalDateTime> tasks  = new HashMap<>();         // chef  → task time
        private final Map<String, String> lastReminder = new HashMap<>();          // recipient → msg

        void reset() {
            orders.clear();
            tasks.clear();
            lastReminder.clear();
        }

        void addOrder(String email, String orderId, String when) {
            orders.put(email + "#" + orderId, LocalDateTime.parse(when, ISO));
        }

        void addTask(String chef, String taskName, String when) {
            tasks.put(chef + "#" + taskName, LocalDateTime.parse(when, ISO));
        }

        void tick(String nowStr) {
            LocalDateTime now = LocalDateTime.parse(nowStr, ISO);

            // فحص طلبات الزبائن
            for (Map.Entry<String, LocalDateTime> e : orders.entrySet()) {
                Duration diff = Duration.between(now, e.getValue());
                String[] key = e.getKey().split("#", 2);
                String email = key[0];
                String orderId = key[1];

                String msg = null;
                if (diff.equals(Duration.ofHours(24))) {
                    msg = orderId + " will be delivered tomorrow";
                } else if (diff.equals(Duration.ofHours(2))) {
                    msg = orderId + " will arrive in about two hours";
                } else if (diff.isZero()) {
                    msg = orderId + " has just been delivered";
                }
                if (msg != null) lastReminder.put(email, msg);
            }

            // فحص مهام الطهاة
            for (Map.Entry<String, LocalDateTime> e : tasks.entrySet()) {
                Duration diff = Duration.between(now, e.getValue());
                String[] key = e.getKey().split("#", 2);
                String chef = key[0];
                String task = key[1];

                String msg = null;
                if (diff.equals(Duration.ofHours(24))) {
                    msg = task + " is scheduled for tomorrow";
                } else if (diff.equals(Duration.ofHours(1))) {
                    msg = task + " starts in one hour";
                } else if (diff.equals(Duration.ofMinutes(10))) {
                    msg = task + " begins in 10 minutes";
                }
                if (msg != null) lastReminder.put(chef, msg);
            }
        }

        String getLastReminder(String recipient) {
            return lastReminder.getOrDefault(recipient, "");
        }
    }

    // خدمة واحدة تُعاد هيكلتها في كل سيناريو عبر الـ Background
    private final ReminderService reminderService = new ReminderService();

    // ـــــــــــــــــــــــ  Given  ـــــــــــــــــــــــ

    @Given("the reminder service has been reset")
    public void the_reminder_service_has_been_reset() {
        reminderService.reset();
    }

    @Given("customer {string} has order {string} scheduled for {string}")
    public void customer_has_order_scheduled_for(String email, String orderId, String when) {
        reminderService.addOrder(email, orderId, when);
    }

    @Given("chef {string} has cooking task {string} at {string}")
    public void chef_has_cooking_task_at(String chef, String taskName, String when) {
        reminderService.addTask(chef, taskName, when);
    }

    // ـــــــــــــــــــــــ  When  ـــــــــــــــــــــــ

    @When("the current time is {string}")
    public void the_current_time_is(String now) {
        reminderService.tick(now);
    }

    // ـــــــــــــــــــــــ  Then  ـــــــــــــــــــــــ

    @Then("customer {string} should receive a reminder containing")
    public void customer_should_receive_a_reminder_containing(String email, String docString) {
        assertReminderContains(email, docString);
    }

    @Then("chef {string} should receive a reminder containing")
    public void chef_should_receive_a_reminder_containing(String chef, String docString) {
        assertReminderContains(chef, docString);
    }

    // ـــــــــــــــــــــــ  مساعد  ـــــــــــــــــــــــ

    private void assertReminderContains(String recipient, String expectedSnippet) {
        String actual = reminderService.getLastReminder(recipient);
        Assertions.assertNotNull(actual, "No reminder found for " + recipient);
        Assertions.assertTrue(actual.contains(expectedSnippet.trim()),
                () -> "Expected reminder to contain:\n" + expectedSnippet + "\nbut was:\n" + actual);
    }
}
