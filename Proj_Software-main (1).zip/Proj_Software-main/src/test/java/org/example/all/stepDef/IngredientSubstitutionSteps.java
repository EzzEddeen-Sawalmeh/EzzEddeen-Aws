// feature 2.2
package org.example.all.stepDef;

import io.cucumber.java.en.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class IngredientSubstitutionSteps {

    private List<String> selectedIngredients = new ArrayList<>();
    private List<String> substitutions = new ArrayList<>();
    private Set<String> unavailableIngredients = Set.of("Caviar", "Truffle");
    private Map<String, String> dietarySubstitutes = Map.of(
            "Milk", "Almond Milk",
            "Cheese", "Vegan Cheese",
            "Beef", "Chicken"
    );
    private List<String> chefNotifications = new ArrayList<>();
    private Set<String> dietaryRestrictions = new HashSet<>();

    // -------- Background --------
    @Given("the customer is logged in and customizing a meal")
    public void the_customer_is_logged_in_and_customizing_a_meal() {
        selectedIngredients.clear();
        substitutions.clear();
        chefNotifications.clear();
        dietaryRestrictions.clear();
    }

    // Customer Scenarios
    @When("the customer selects ingredients: {string}")
    public void the_customer_selects_ingredients(String ingredients) {
        selectedIngredients = Arrays.asList(ingredients.split("\\s*,\\s*"));
    }

    @When("the dietary restriction is {string}")
    public void the_dietary_restriction_is(String string) {
        dietaryRestrictions.addAll(Arrays.asList(string.split("\\s*,\\s*")));
    }

    @Then("the system suggests alternatives for unavailable ingredients")
    public void the_system_suggests_alternatives_for_unavailable_ingredients() {
        for (String ingredient : selectedIngredients) {
            if (unavailableIngredients.contains(ingredient)) {
                substitutions.add("Mushrooms");
                notifyChef("Substitution for " + ingredient + ": Mushrooms");
            }
        }
        assertFalse(substitutions.isEmpty());
    }

    @Then("the system suggests alternatives for restricted ingredients")
    public void the_system_suggests_alternatives_for_restricted_ingredients() {
        for (String ingredient : selectedIngredients) {
            if ((ingredient.equalsIgnoreCase("Milk") && dietaryRestrictions.contains("No Dairy")) ||
                    (ingredient.equalsIgnoreCase("Cheese") && dietaryRestrictions.contains("No Dairy")) ||
                    (ingredient.equalsIgnoreCase("Beef") && dietaryRestrictions.contains("No Red Meat"))) {
                String substitute = dietarySubstitutes.getOrDefault(ingredient, "Unknown Substitute");
                substitutions.add(substitute);
                notifyChef("Substitution for " + ingredient + ": " + substitute);
            }
        }
        assertFalse(substitutions.isEmpty());
    }

    @Then("the suggested substitutions include: {string}")
    public void the_suggested_substitutions_include(String string) {
        List<String> expectedSubs = Arrays.asList(string.split("\\s*,\\s*"));
        assertTrue(substitutions.containsAll(expectedSubs));
    }

    // Chef Scenarios
    @Given("a substitution was made for a custom meal")
    public void a_substitution_was_made_for_a_custom_meal() {
        substitutions = new ArrayList<>(List.of("Mushrooms", "Almond Milk"));
        notifyChef("Substitutions: " + String.join(", ", substitutions));
    }

    @Then("the chef is notified with the substituted ingredients")
    public void the_chef_is_notified_with_the_substituted_ingredients() {
        assertFalse(chefNotifications.isEmpty());
        System.out.println("Chef notified: " + chefNotifications.get(0));
    }

    @When("the chef opens the meal request")
    public void the_chef_opens_the_meal_request() {
    }

    @Then("the system shows the list of substituted ingredients")
    public void the_system_shows_the_list_of_substituted_ingredients() {
        assertFalse(substitutions.isEmpty());
        System.out.println("Substitution list: " + substitutions);
    }

    @When("the chef edits the substituted ingredients")
    public void the_chef_edits_the_substituted_ingredients() {
        if (!substitutions.isEmpty()) {
            substitutions.set(0, "Tofu");
        }
    }

    @Then("the updated substitutions are saved")
    public void the_updated_substitutions_are_saved() {
        assertEquals("Tofu", substitutions.get(0));
        System.out.println("Updated substitutions: " + substitutions);
    }

    private void notifyChef(String message) {
        chefNotifications.add(message);
    }
}
