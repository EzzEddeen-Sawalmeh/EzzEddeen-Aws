// feature 2.1
package org.example.all.stepDef;

import io.cucumber.java.Before;
import io.cucumber.java.en.*;

import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

public class CustomMealSteps {

    static class Customer {
        String email;
        List<String> customMeals = new ArrayList<>();

        Customer(String email) {
            this.email = email;
        }
    }

    private final Map<String, Customer> customers = new HashMap<>();
    private String currentEmail;
    private List<String> selectedIngredients = new ArrayList<>();
    private String lastErrorMessage = "";

    @Before
    public void initCustomers() {
        customers.put("ali@test.com", new Customer("ali@test.com"));
        customers.put("layla@test.com", new Customer("layla@test.com"));
        customers.put("karim@test.com", new Customer("karim@test.com"));
        customers.put("sara@test.com", new Customer("sara@test.com"));
        customers.put("john@test.com", new Customer("john@test.com"));
        customers.put("hana@test.com", new Customer("hana@test.com"));
    }

    // ---------- Customer Scenarios ----------

    @Given("the customer {string} is creating a new custom meal")
    public void the_customer_is_creating_a_new_custom_meal(String email) {
        currentEmail = email;
        selectedIngredients = new ArrayList<>();
        customers.putIfAbsent(email, new Customer(email));
    }

    @When("the customer chooses ingredients for substitution: {string}")
    public void the_customer_selects_ingredients(String ingredients) {
        selectedIngredients = ingredients.isBlank()
                ? new ArrayList<>()
                : Arrays.asList(ingredients.split("\\s*,\\s*"));

        // Validation for various cases
        if (selectedIngredients.isEmpty()) {
            lastErrorMessage = "No ingredients selected";
        } else if (selectedIngredients.size() > 7) {
            lastErrorMessage = "Too many ingredients selected";
        } else if (hasIncompatibleCombination(selectedIngredients)) {
            lastErrorMessage = "Incompatible ingredients selected";
        } else if (hasUnavailableIngredients(selectedIngredients)) {
            lastErrorMessage = "Some ingredients are not available";
        } else {
            lastErrorMessage = "";
        }
    }

    @When("submits the meal request")
    public void submits_the_meal_request() {
        if (lastErrorMessage.isEmpty()) {
            Customer c = customers.get(currentEmail);
            c.customMeals.add(String.join(", ", selectedIngredients));
        }
    }

    @Then("the system confirms the custom meal request")
    public void the_system_confirms_the_custom_meal_request() {
        assertTrue(lastErrorMessage.isEmpty(), "Expected success, but got error: " + lastErrorMessage);
        Customer c = customers.get(currentEmail);
        assertFalse(c.customMeals.isEmpty());
        System.out.println("✅ Meal created: " + c.customMeals.get(c.customMeals.size() - 1));
    }

    @Then("the system shows the error {string}")
    public void the_system_displays_an_error_message(String expectedMessage) {
        assertEquals(expectedMessage, lastErrorMessage);
        System.out.println("❌ " + lastErrorMessage);
    }


    private boolean hasIncompatibleCombination(List<String> ingredients) {
        Set<Set<String>> incompatiblePairs = Set.of(
                Set.of("Milk", "Lemon"),
                Set.of("Fish", "Cheese"),
                Set.of("Orange", "Yogurt")
        );
        for (Set<String> pair : incompatiblePairs) {
            if (ingredients.containsAll(pair)) {
                return true;
            }
        }
        return false;
    }

    private boolean hasUnavailableIngredients(List<String> ingredients) {
        Set<String> unavailable = Set.of("Dragon Fruit", "Caviar", "Truffle", "Gold Flakes", "Blue Lobster", "Unicorn Meat");
        for (String i : ingredients) {
            if (unavailable.contains(i)) return true;
        }
        return false;
    }
}
