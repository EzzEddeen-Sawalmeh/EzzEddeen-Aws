// feature 1.1
package org.example.all.stepDef;

import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

public class CustomerPreferencesStepDefs {

    private static class Customer {
        String email;
        List<String> preferences = new ArrayList<>();
        List<String> allergies = new ArrayList<>();

        Customer(String email) {
            this.email = email;
        }
    }

    private final Map<String, Customer> customerMap = new HashMap<>();
    private String currentEmail;
    private String currentPreference;
    private String currentAllergy;
    private boolean validInput = true;

    @Before
    public void seedCustomers() {
        Customer ali = new Customer("ali@test.com");
        ali.preferences.add("Vegan");
        ali.allergies.add("Peanuts");

        Customer layla = new Customer("layla@test.com");
        layla.preferences.add("Vegetarian");
        layla.allergies.add("Shellfish");

        Customer karim = new Customer("karim@test.com");
        karim.preferences.add("Gluten-Free");
        karim.allergies.add("Dairy");

        customerMap.put(ali.email, ali);
        customerMap.put(layla.email, layla);
        customerMap.put(karim.email, karim);
    }

    // ---------------- Customer Scenarios ----------------

    @When("the customer {string} enters dietary preference {string} and allergy {string}")
    public void enter_preference_and_allergy(String email, String preference, String allergy) {
        currentEmail = email;
        currentPreference = preference;
        currentAllergy = allergy;

        validInput = isValid(preference) && isValid(allergy);

        customerMap.putIfAbsent(email, new Customer(email));
    }

    @When("submits the information")
    public void submits_information() {
        if (!validInput) return;
        Customer c = customerMap.get(currentEmail);
        c.preferences.add(currentPreference);
        c.allergies.add(currentAllergy);
    }

    @Then("the system should save the preference and allergy for {string}")
    public void saved_preference_allergy(String email) {
        Customer c = customerMap.get(email);
        assertNotNull(c);
        assertTrue(c.preferences.contains(currentPreference));
        assertTrue(c.allergies.contains(currentAllergy));
    }

    @Then("the system displays an error message {string}")
    public void show_error(String msg) {
        assertFalse(validInput);
        System.out.println("❌ " + msg);
    }

    private boolean isValid(String value) {
        return value != null && !value.trim().isEmpty()
                && !value.matches(".*\\d.*")
                && !value.contains("@") && !value.contains("#") && !value.contains("*");
    }

    @Given("the customer {string} already has preferences")
    public void customer_has_preferences(String email) {
        customerMap.putIfAbsent(email, new Customer(email));
        customerMap.get(email).preferences.add("InitialPref");
        currentEmail = email;
    }

    @When("they update their preference to {string}")
    public void update_preference(String newPref) {
        Customer c = customerMap.get(currentEmail);
        if (!c.preferences.isEmpty()) {
            c.preferences.set(0, newPref);
        } else {
            c.preferences.add(newPref);
        }
        currentPreference = newPref;
    }

    @Then("the system should reflect the updated preference for {string}")
    public void assert_updated_preference(String email) {
        Customer c = customerMap.get(email);
        assertNotNull(c);
        assertEquals(currentPreference, c.preferences.get(0));
    }

    // ---------------- Chef Scenarios ----------------

    @Given("the chef opens the profile of {string}")
    public void chef_opens_profile(String email) {
        currentEmail = email;
    }

    @Then("the system displays the stored preferences and allergies")
    public void the_system_displays_the_stored_preferences_and_allergies() {
        Customer c = customerMap.get(currentEmail);
        assertNotNull(c);
        System.out.println("Preferences: " + c.preferences);
        System.out.println("Allergies: " + c.allergies);
    }

    @Then("the system displays the message {string}")
    public void system_displays_message(String msg) {
        Customer c = customerMap.get(currentEmail);
        boolean noData = (c == null || (c.preferences.isEmpty() && c.allergies.isEmpty()));
        assertTrue(noData);
        System.out.println(msg);
    }

    @Then("the system suggests a custom meal plan based on preferences")
    public void suggest_meal_plan() {
        Customer c = customerMap.get(currentEmail);
        assertNotNull(c);
        assertFalse(c.preferences.isEmpty());
        System.out.println("📋 Meal plan for " + currentEmail + " based on: " + c.preferences);
    }
}