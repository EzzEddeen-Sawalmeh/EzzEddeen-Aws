//feature 2.1
package org.example.all.test;

import org.example.all.stepDef.CustomMealSteps;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class CustomMealStepsTest {

    private CustomMealSteps steps;

    @BeforeEach
    void setUp() {
        steps = new CustomMealSteps();
        steps.initCustomers();
    }

    @Test
    void testValidCustomMeal() {
        steps.the_customer_is_creating_a_new_custom_meal("ali@test.com");
        steps.the_customer_selects_ingredients("Chicken, Rice, Broccoli");
        steps.submits_the_meal_request();
        assertDoesNotThrow(() -> steps.the_system_confirms_the_custom_meal_request());
    }

    @Test
    void testEmptyIngredientList() {
        steps.the_customer_is_creating_a_new_custom_meal("sara@test.com");
        steps.the_customer_selects_ingredients("");
        steps.the_system_displays_an_error_message("No ingredients selected");
    }

    @Test
    void testTooManyIngredients() {
        steps.the_customer_is_creating_a_new_custom_meal("karim@test.com");
        steps.the_customer_selects_ingredients("Beef, Potato, Carrot, Mushroom, Chili, Peas, Milk, Honey");
        steps.the_system_displays_an_error_message("Too many ingredients selected");
    }

    @Test
    void testIncompatibleIngredients() {
        steps.the_customer_is_creating_a_new_custom_meal("ali@test.com");
        steps.the_customer_selects_ingredients("Milk, Lemon");
        steps.the_system_displays_an_error_message("Incompatible ingredients selected");
    }

    @Test
    void testUnavailableIngredients() {
        steps.the_customer_is_creating_a_new_custom_meal("hana@test.com");
        steps.the_customer_selects_ingredients("Blue Lobster, Unicorn Meat");
        steps.the_system_displays_an_error_message("Some ingredients are not available");
    }

    @Test
    void testBorderlineValidIngredients() {
        steps.the_customer_is_creating_a_new_custom_meal("layla@test.com");
        steps.the_customer_selects_ingredients("Brown Rice, Lentils, Cabbage");
        steps.submits_the_meal_request();
        assertDoesNotThrow(() -> steps.the_system_confirms_the_custom_meal_request());
    }

    @Test
    void testMultipleValidMeals() {
        steps.the_customer_is_creating_a_new_custom_meal("karim@test.com");
        steps.the_customer_selects_ingredients("Tuna, Tomato, Arugula");
        steps.submits_the_meal_request();
        assertDoesNotThrow(() -> steps.the_system_confirms_the_custom_meal_request());

        steps.the_customer_is_creating_a_new_custom_meal("karim@test.com");
        steps.the_customer_selects_ingredients("Salmon, Sweet Potato, Kale");
        steps.submits_the_meal_request();
        assertDoesNotThrow(() -> steps.the_system_confirms_the_custom_meal_request());
    }
}
