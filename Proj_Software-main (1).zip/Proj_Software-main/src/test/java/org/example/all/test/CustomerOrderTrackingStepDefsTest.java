//feature 1.2
package org.example.all.test;

import static org.junit.jupiter.api.Assertions.*;

import org.example.all.stepDef.CustomerOrderTrackingStepDefs;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CustomerOrderTrackingStepDefsTest {

    private CustomerOrderTrackingStepDefs stepDefs;

    @BeforeEach
    void setUp() {
        stepDefs = new CustomerOrderTrackingStepDefs();
        stepDefs.initData();
    }

    @Test
    void testViewPastOrders() {
        stepDefs.the_customer_requests_to_view_past_orders("ali@test.com");
        assertDoesNotThrow(() -> stepDefs.the_system_displays_previous_meals_ordered_by("ali@test.com"));

        stepDefs.the_customer_requests_to_view_past_orders("ghost@test.com");
        assertThrows(AssertionError.class, () -> stepDefs.the_system_displays_previous_meals_ordered_by("ghost@test.com"));
    }

    @Test
    void testNoPreviousOrdersFound() {
        stepDefs.the_customer_requests_to_view_past_orders("newuser@test.com");
        assertDoesNotThrow(() -> stepDefs.the_system_displays("No previous orders found"));
    }

    @Test
    void testReorderMeal() {
        stepDefs.the_customer_requests_to_view_past_orders("layla@test.com");
        stepDefs.selects_to_reorder("Salad Bowl");
        assertDoesNotThrow(() -> stepDefs.the_system_processes_a_new_order_for("Salad Bowl"));
    }

    @Test
    void testMealHistory() {
        assertDoesNotThrow(() -> stepDefs.the_system_displays_the_customer_s_meal_history());
    }

    @Test
    void testPersonalizedMealPlan() {
        assertDoesNotThrow(() -> stepDefs.suggests_a_personalized_meal_plan());
    }

    @Test
    void testAdminOrderSummary() {
        stepDefs.the_administrator_accesses_order_data_for("karim@test.com");
        assertDoesNotThrow(() -> stepDefs.the_system_returns_a_summary_of_order_frequency_and_types());
    }

    @Test
    void testAdminWithNoActivity() {
        stepDefs.the_administrator_accesses_order_data_for("newuser@test.com");
        assertDoesNotThrow(() -> stepDefs.the_system_returns_a_summary_with("No activity found"));
    }

    @Test
    void testAdminWithNonExistingCustomer() {
        stepDefs.the_administrator_accesses_order_data_for("ghost@test.com");
        assertDoesNotThrow(() -> stepDefs.the_system_returns_a_summary_with("No activity found"));
    }
}
