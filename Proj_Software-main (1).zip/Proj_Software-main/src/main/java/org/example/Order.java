package org.example;

import java.time.LocalDate;

public class Order {
    private String mealName;
    private LocalDate orderDate;

    public Order(String mealName, LocalDate orderDate) {
        if (mealName == null || mealName.isEmpty()) {
            throw new IllegalArgumentException("Meal name cannot be null or empty");
        }
        this.mealName = mealName;
        this.orderDate = orderDate != null ? orderDate : LocalDate.now(); // Ensure the date is valid
    }

    public String getMealName() {
        return mealName;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Order order = (Order) obj;
        return mealName.equals(order.mealName) && orderDate.equals(order.orderDate);
    }

    @Override
    public int hashCode() {
        return mealName.hashCode() + orderDate.hashCode();
    }
}
