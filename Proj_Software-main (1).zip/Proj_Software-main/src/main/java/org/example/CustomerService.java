package org.example;

import java.util.ArrayList;
import java.util.List;

public class CustomerService {
    private List<Customer> customers = new ArrayList<>();

    public void addCustomer(Customer customer) {
        if (customer != null && !findCustomerByEmail(customer.getEmail())) {
            customers.add(customer);
        }
    }

    public boolean findCustomerByEmail(String email) {
        return customers.stream().anyMatch(c -> c.getEmail().equalsIgnoreCase(email));
    }

    public List<String> getDietaryPreferences(String email) {
        Customer c = findCustomerByEmail(email) ? customers.stream().filter(cus -> cus.getEmail().equals(email)).findFirst().get() : null;
        return (c != null) ? c.getDietaryPreferences() : new ArrayList<>();
    }

    public List<String> getAllergies(String email) {
        Customer c = findCustomerByEmail(email) ? customers.stream().filter(cus -> cus.getEmail().equals(email)).findFirst().get() : null;
        return (c != null) ? c.getAllergies() : new ArrayList<>();
    }

    public List<Order> getOrderHistory(String email) {
        Customer c = findCustomerByEmail(email) ? customers.stream().filter(cus -> cus.getEmail().equals(email)).findFirst().get() : null;
        return (c != null) ? c.getOrderHistory() : new ArrayList<>();
    }
}
