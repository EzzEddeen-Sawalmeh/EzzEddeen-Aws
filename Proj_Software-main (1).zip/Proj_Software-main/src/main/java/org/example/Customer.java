package org.example;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String name;
    private String email;
    private List<String> dietaryPreferences;
    private List<String> allergies;
    private List<Order> orderHistory;

    public Customer(String name, String email) {
        this.name = name;
        this.email = email;
        this.dietaryPreferences = new ArrayList<>();
        this.allergies = new ArrayList<>();
        this.orderHistory = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public List<String> getDietaryPreferences() {
        return dietaryPreferences;
    }

    public List<String> getAllergies() {
        return allergies;
    }

    public List<Order> getOrderHistory() {
        return orderHistory;
    }

    public void addDietaryPreference(String preference) {
        if (preference != null && !preference.isEmpty() && !dietaryPreferences.contains(preference)) {
            dietaryPreferences.add(preference);
        }
    }

    public void addAllergy(String allergy) {
        if (allergy != null && !allergy.isEmpty() && !allergies.contains(allergy)) {
            allergies.add(allergy);
        }
    }

    public void addOrder(Order order) {
        if (order != null && !orderHistory.contains(order)) {
            orderHistory.add(order);
        }
    }
}
