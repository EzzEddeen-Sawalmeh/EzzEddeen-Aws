package org.example;

import java.time.LocalDate;

public class MainApp
{
    public static void main(String[] args) {
        CustomerService service = new CustomerService();

        Customer ali = new Customer("Ali", "ali@example.com");
        ali.addDietaryPreference("Vegan");
        ali.addAllergy("meat");

        Order order = new Order("Vegan Pasta", LocalDate.now());
        ali.addOrder(order);

        service.addCustomer(ali);

        System.out.println("Customer: " + ali.getName());
        System.out.println("Dietary Preferences: " + ali.getDietaryPreferences());
        System.out.println("Allergies: " + ali.getAllergies());
        System.out.println("Order History:");
        for (Order o : ali.getOrderHistory())
        {
            System.out.println("- " + o.getMealName() + " on " + o.getOrderDate());
        }
    }
}
